import {
  Chart,
  Series,
  Title
} from 'highcharts-react-official';

function App() {
  return (
    <Chart>
      <Title>React + Highcharts</Title>

      <Series type="line" data={[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]} />
    </Chart>
  )
}

export default App
