# React + TypeScript + Vite + Highcharts

Sample using Highcharts in React with TypeScript and Vite.

## Quick start

* Install with `npm i`
* Run the development server with `npm run dev`


See the [Vite documentation](https://vite.dev/guide/) for more advanced use
