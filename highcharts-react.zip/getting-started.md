# Getting started

## Requirements

The current release has been tested with:

* Node version 22.11 and npm version 10
* The [Highcharts npm package](https://www.npmjs.com/package/highcharts) version 11.4.8
* [Vite](https://vite.dev/) with [plugin-react](https://www.npmjs.com/package/@vitejs/plugin-react) version 4.3.3
* React and react-dom version 18.3.1

# Install Highcharts and highcharts-react

Install Highcharts along with the React wrapper by running:

```sh
npm install highcharts github:highcharts/highcharts-react#v4-dev
```

## Import Highcharts and Series Components

In your JSX file, import the necessary components:

```jsx
import {
    Chart,
    Series
} from 'highcharts-react-official';
```

Now, you can create a simple chart like this:

```jsx
<Chart>
  <Series type="column" data={[1, 2, 3]} />
</Chart>
```

### Specific Series Components

For series that are outside the main Highcharts bundle, you can import them directly. This helps manage required imports seamlessly.

For example, to use a Venn diagram series:

```jsx
import { VennSeries } from 'highcharts-react-official/series/Venn';
```

Use the specific series component just like the generic `Series`, but omit the `type` prop:

```jsx
<Chart>
  <VennSeries data={[/* your data */]} />
</Chart>
```

## Customize with Option Components

Enhance your chart by adding option components:

```jsx
import {
    Title,
    Subtitle,
    Credits,
    XAxis,
    YAxis,
    PlotOptions,
    Tooltip,
    Legend
} from 'highcharts-react-official';
```

Here's an example of adding a custom title:

```jsx
<Chart>
  <Title>Custom Chart Title</Title>
  <Series type="column" data={[1, 2, 3]} />
</Chart>
```

Most top-level properties can be set as props. If an option component has a `text` or `format` property,
you can set it by passing children to the component.

With the `Tooltip` component, you can customize the information displayed using a [format string](https://www.highcharts.com/docs/chart-concepts/templating). Here's a simple example:

```jsx
<Chart>
  <Series type="column" data={[1, 2, 3]} />

  <Tooltip>{'X: {point.x}, Y: {point.y}'}</Tooltip>
</Chart>
```

If you prefer more flexibility, you can use React components and elements as children:

```jsx
function TooltipFormat() {
  return (
    <>
      <div data-hc-option="headerFormat">
        <strong>{'Series {series.name}'}</strong>
      </div>
      <div data-hc-option="pointFormat">
        {'X: {point.x}, Y: {point.y}'}
      </div>
      <div data-hc-option="footerFormat">
        <em>Footer text</em>
      </div>
    </>
  );
}

function ChartComponent() {
  return (
    <Chart>
      <Series type="column" data={[1, 2, 3]} />

      <Tooltip>
        <TooltipFormat />
      </Tooltip>
    </Chart>
  );
}
```

**Note:** The `data-hc-option` attributes link the elements to `tooltip.headerFormat`, `tooltip.pointFormat`, and `tooltip.footerFormat`.


## Setting Options Using the `options` Prop

Alternatively, you can configure your chart using the `options` prop:

```jsx
<Chart options={chartOptions} />
```

This method allows you to define chart types, data, and specific Highcharts configurations within a single object.

## Accessing the Highcharts Instance

If you need to set global Highcharts options or use global methods, access the `Highcharts` export:

```jsx
import { Highcharts } from 'highcharts-react-official';

Highcharts.setOptions({
    chart: {
        animation: false
    }
});

export default function MyChartComponent(){
  // Your component code
}
```

**Note:** Setting global options will affect all charts rendered using the Highcharts instance, so use this feature thoughtfully.

---

Feel free to reach out if you have any questions or need further assistance. We're here to help make your data visualization experience smooth and enjoyable!
